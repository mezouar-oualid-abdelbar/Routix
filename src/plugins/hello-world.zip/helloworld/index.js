// plugins/hello-world.js
//
// This is the plugin — the code a third party writes and you'd later
// fetch from your registry instead of importing locally like this.
// It only ever touches the `Plugin` object exposed by the sandbox.

export const helloWorldPlugin = `
Plugin.onLoad(function () {
  Plugin.showText("Hello World from my first plugin!");
});
`;
